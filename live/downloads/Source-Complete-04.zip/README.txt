Source Complete 04 — experimental variable Latin font

528 encoded characters; 592 required named glyphs, plus helper components.
Axes: Weight 350–550, Width 85–115, custom Height 600–800.
The selected source controls retain their default shapes. Remaining glyphs
are authored using same-family components; no unrelated font outlines.
M/m uses one shared lowercase middle stem and one uppercase central junction.

This is a complete-inventory experimental font, not production design approval.
Optical refinement, symbol detail and whole-family consistency remain under review.
Contains real variable TTF/WOFF2, named static instances, declared inventory,
and technical/shaping validation. Reference images are intentionally excluded.
